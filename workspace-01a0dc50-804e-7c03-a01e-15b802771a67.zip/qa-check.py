#!/usr/bin/env python3
"""Final QA suite for the Usama Habib portfolio (Step 8). Writes QA-REPORT.md."""
import re, pathlib, datetime

ROOT = pathlib.Path("/home/user/usama-portfolio")
PUBLIC = ["index.html", "portfolio.html", "about.html", "services.html", "contact.html"]
ALL = PUBLIC + ["admin.html"]
results = []

def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))

def read(p): return (ROOT / p).read_text(encoding="utf-8")

# ---------- 1. pages exist ----------
for f in ALL:
    check(f"Page exists: {f}", (ROOT / f).exists())

html = {f: read(f) for f in ALL if (ROOT / f).exists()}

# ---------- 2. asset refs resolve ----------
for f, h in html.items():
    refs = sorted(set(re.findall(r'''(?:src|href)="(assets/[^"]+)"''', h)))
    missing = [r for r in refs if not (ROOT / r).exists()]
    check(f"Assets resolve: {f} ({len(refs)} refs)", not missing, f"missing={missing}" if missing else "")

# ---------- 3. CSS url() refs (non-data) ----------
for css in sorted((ROOT / "assets/css").glob("*.css")):
    t = css.read_text()
    urls = [u for u in re.findall(r"url\(([^)]+)\)", t) if not u.strip().strip(chr(39)+chr(34)).startswith("data:")]
    missing = [u for u in urls if not (css.parent / u.strip('\'"')).exists()]
    check(f"CSS urls resolve: {css.name}", not missing, f"missing={missing}" if missing else "")

# ---------- 4. internal page links + anchors ----------
for f, h in html.items():
    links = sorted(set(re.findall(r'href="([^"#]+?\.html)(#[^"]*)?"', h)))
    bad = [l for l, _ in links if l not in ALL]
    check(f"Page links valid: {f}", not bad, f"bad={bad}" if bad else "")
    for target, anchor in sorted(set(re.findall(r'href="([^"]*?\.html)?(#[A-Za-z][\w-]*)"', h))):
        page = target if target else f
        if page in html:
            aid = anchor[1:]
            if f'id="{aid}"' not in html[page]:
                check(f"Anchor #{aid} in {page} (from {f})", False, "missing id")
check("All anchors resolve", all(r[1] for r in results if r[0].startswith("Anchor #")) or not any(r[0].startswith("Anchor #") for r in results))

# ---------- 5. nav consistency + single active ----------
for f in PUBLIC:
    h = html[f]
    m = re.search(r'id="navLinks">(.*?)</div>', h, re.S)
    nav = m.group(1) if m else ""
    has_all = all(f'href="{p}"' in nav for p in PUBLIC)
    actives = re.findall(r'class="([^"]*\bactive\b[^"]*)"', nav)
    active_ok = len(actives) == 1 and f'href="{f}" class="active"' in nav.replace('class="active" aria', 'class="active"')
    # simpler: the active anchor's href must equal this page
    am = re.search(r'href="([^"]+)" class="active"', nav)
    active_ok = am and am.group(1) == f and len(actives) == 1
    check(f"Nav complete + active correct: {f}", has_all and active_ok, "" if (has_all and active_ok) else f"has_all={has_all} actives={len(actives)}")

# ---------- 6. engine before main.js ----------
for f in PUBLIC:
    h = html[f]
    ie, im = h.find("assets/js/engine.js"), h.find('assets/js/main.js"')
    check(f"engine.js before main.js: {f}", 0 <= ie < im)
ha = html.get("admin.html", "")
check("admin.html loads engine+admin", "assets/js/engine.js" in ha and "assets/js/admin.js" in ha
      and ha.find("engine.js") < ha.find("admin.js"))

# ---------- 7. required IDs ----------
need = {
    "index.html": ["siteHeader", "navLinks", "navToggle", "year"],
    "portfolio.html": ["siteHeader", "navLinks", "navToggle", "year", "galGrid", "galCount", "galDesc", "lightbox", "lbImg", "lbPill", "lbTitle", "lbDesc", "lbCount", "heroTotal"],
    "about.html": ["siteHeader", "navLinks", "navToggle", "year"],
    "services.html": ["siteHeader", "navLinks", "navToggle", "year"],
    "contact.html": ["siteHeader", "navLinks", "navToggle", "year", "contactForm", "fName", "fEmail", "fBiz", "fProduct", "fService", "fBudget", "fMsg", "formSuccess"],
    "admin.html": ["admAuth", "admLoginForm", "admUser", "admPass", "admErr", "admApp", "admNav", "admLogout", "admToast", "admMeterBar", "admMeterTxt"],
}
for f, ids in need.items():
    missing = [i for i in ids if f'id="{i}"' not in html.get(f, "")]
    check(f"Required IDs: {f}", not missing, f"missing={missing}" if missing else "")
# admin panes <-> tabs
panes = set(re.findall(r'id="(pane-\w+)"', ha))
tabs = set("pane-" + t for t in re.findall(r'data-pane="(\w+)"', ha))
check("Admin tabs match panes (11)", panes == tabs and len(panes) == 11, f"panes={len(panes)} tabs={len(tabs)}")

# ---------- 8. portfolio gallery ----------
ph = html.get("portfolio.html", "")
figs = re.findall(r'<figure class="gal-item[^"]*" data-cat="([^"]+)" data-title="([^"]*)" data-desc="([^"]*)"', ph)
valid_cats = {"ecommerce", "perfume", "skincare", "jewelry", "watches", "food", "lifestyle", "creative"}
check("Gallery has 17 figures", len(figs) == 17, f"found={len(figs)}")
check("Gallery cats valid", all(c in valid_cats for c, _, _ in figs))
check("Gallery titles+descs present", all(t and d for _, t, d in figs))
check("Gallery wide slots = 3", ph.count("gal-item--wide") >= 3, f"found={ph.count('gal-item--wide')}")
check("Lightbox controls present", all(x in ph for x in ["lb__prev", "lb__next", "lb__close", "data-lb-close"]))
check("Filter tabs = 9 (All+8)", ph.count('<button class="tab') == 9, f"found={ph.count(chr(60)+chr(98)+'utton class="tab')}")

# ---------- 9. images ----------
imgs = sorted((ROOT / "assets/images").glob("*"))
check("Images folder non-empty", len(imgs) >= 17, f"found={len(imgs)}")
small = [p.name for p in imgs if p.stat().st_size < 5000]
check("All images > 5KB", not small, f"small={small}" if small else "")
dims = []
try:
    from PIL import Image
    for p in imgs:
        with Image.open(p) as im: dims.append(f"{p.name} {im.size[0]}x{im.size[1]} {im.format}")
    check("All images open as valid pictures (PIL)", True, f"{len(dims)} verified")
except Exception as e:
    check("PIL check skipped", True, f"PIL unavailable: {e}")
total_mb = sum(p.stat().st_size for p in imgs) / 1024 / 1024

# ---------- 10. css/js wiring ----------
expect_css = {"index.html": ["styles.css"], "portfolio.html": ["styles.css", "portfolio.css"],
              "about.html": ["styles.css", "about.css"], "services.html": ["styles.css", "services.css"],
              "contact.html": ["styles.css", "contact.css"], "admin.html": ["styles.css", "admin.css"]}
for f, csss in expect_css.items():
    check(f"CSS linked: {f}", all(c in html[f] for c in csss))
for js in ["engine.js", "main.js", "portfolio.js", "contact.js", "admin.js"]:
    check(f"JS exists: {js}", (ROOT / "assets/js" / js).exists())

# ---------- 11. meta / titles / noindex ----------
for f, h in html.items():
    check(f"Viewport+title: {f}", 'name="viewport"' in h and "<title>" in h and "</title>" in h)
check("admin noindex, public indexable", 'name="robots" content="noindex' in html["admin.html"]
      and all("noindex" not in html[f] for f in PUBLIC))

# ---------- 12. form labels ----------
cf = html.get("contact.html", "")
cform = re.search(r'<form id="contactForm"(.*?)</form>', cf, re.S).group(0)
field_ids = re.findall(r'<(?:input|select|textarea)[^>]*id="([^"]+)"', cform)
unlabeled = [i for i in field_ids if f'for="{i}"' not in cform]
check("Contact fields all labeled", not unlabeled, f"unlabeled={unlabeled}" if unlabeled else f"({len(field_ids)} fields)")
check("Required marks on name/email/message", all(x in cform for x in ['id="fName"', 'id="fEmail"', 'id="fMsg"']) and cform.count("required") >= 3)

# ---------- 13. alt text ----------
for f, h in html.items():
    tags = re.findall(r"<img\b[^>]*>", h)
    noalt = [t for t in tags if "alt=" not in t]
    check(f"All imgs have alt: {f} ({len(tags)})", not noalt, f"noalt={len(noalt)}")
eng = read("assets/js/engine.js")
check("Engine templates include alt", eng.count("<img") > 0 and eng.count("alt=") >= eng.count("<img"),
      f"img={eng.count('<img')} alt={eng.count('alt=')}")

# ---------- 14. dead placeholder links ----------
for f in PUBLIC:
    hrefs = re.findall(r'href="([^"]*)"', html[f])
    dead = [x for x in hrefs if x in ("", "#") ]
    # allow "#" only on data-social anchors (wired by JS)
    social_hash = len(re.findall(r'<a[^>]*href="#"[^>]*data-social', html[f])) + len(re.findall(r'<a[^>]*data-social[^>]*href="#"', html[f]))
    check(f"No dead links: {f}", len(dead) == social_hash, f"dead={len(dead)} social={social_hash}" if len(dead) != social_hash else "")

# ---------- 15. data-social keys ----------
allowed = {"email", "whatsapp", "instagram", "facebook", "linkedin", "behance"}
for f, h in html.items():
    keys = set(re.findall(r'data-social="(\w+)"', h))
    check(f"Social keys valid: {f}", keys <= allowed, f"keys={keys - allowed}" if keys - allowed else "")

# ---------- 16. stale refs ----------
stale = []
for f, h in html.items():
    for bad in ["cosmetics-float", "perfume-smoke"]:
        if bad in h: stale.append(f"{f}:{bad}")
for js in (ROOT / "assets/js").glob("*.js"):
    t = js.read_text()
    for bad in ["cosmetics-float", "perfume-smoke"]:
        if bad in t: stale.append(f"{js.name}:{bad}")
check("No refs to ungenerated images", not stale, f"{stale}" if stale else "")

# ---------- 17. engine defaults sanity ----------
check("Engine: 17 portfolio items", eng.count('cat: "') == 17, f"found={eng.count('cat: \"')}")
check("Engine: 8 categories", eng.count('short: "') == 8, f"found={eng.count('short: \"')}")
check("Engine: featured 5", len(re.findall(r'"assets/images/[\w-]+\.jpg"', eng.split("featured: [")[1].split("]")[0])) == 5 if "featured: [" in eng else False)
check("Engine: 6 services", eng.count('kicker: "') == 6, f"found={eng.count('kicker: \"')}")
check("Engine: 8 skills", eng.count("Retouching / Image Enhancement") == 1 and eng.count('label: "') >= 8)

# ---------- 18. responsive css ----------
for css in ["styles.css", "portfolio.css", "about.css", "services.css", "contact.css", "admin.css"]:
    t = (ROOT / "assets/css" / css).read_text()
    check(f"Responsive rules: {css}", "@media" in t)

# ---------- 19. footer labels consistent ----------
labels = {f: ("Ready to Launch" not in h and "of 8 ·" not in h) for f, h in html.items() if f in PUBLIC}
check("Build labels removed from footers", all(labels.values()), f"{labels}")

# ---------- report ----------
passed = sum(1 for _, ok, _ in results if ok)
failed = [(n, d) for n, ok, d in results if not ok]
lines = ["# QA Report — Usama Habib Portfolio (Final)",
         f"\n**Date:** {datetime.date.today().isoformat()} · **Result: {passed}/{len(results)} checks passed**",
         "\n## Automated checks\n", "| # | Check | Result | Detail |", "|---|-------|--------|--------|"]
for i, (n, ok, d) in enumerate(results, 1):
    lines.append(f"| {i} | {n} | {'✅ PASS' if ok else '❌ FAIL'} | {d} |")
lines += ["\n## Asset summary", f"\n- Images: {len(imgs)} files, {total_mb:.1f} MB total"]
if dims: lines += ["- Dimensions:", *[f"  - {x}" for x in dims]]
lines += ["\n## Manual checks (do once on a real phone + computer)",
  "1. Open every page on mobile — menu opens/closes, nothing overflows sideways.",
  "2. Portfolio: tap each filter tab, open the lightbox, use ←/→ and Esc.",
  "3. Contact: submit the form — email app opens with everything pre-filled.",
  "4. Admin: sign in, change the tagline, check Home in Live Preview, then Reset.",
  "5. Theme tab: try all 4 presets + custom colors; confirm the whole site follows.",
  "6. Upload one photo in Portfolio & Images; confirm it appears in gallery + lightbox.",
  "7. Add one Reel link; confirm the Home motion section appears.",
  "8. Export backup JSON + download site-config.js; confirm both download.",
  "\n*End of report.*"]
(ROOT / "QA-REPORT.md").write_text("\n".join(lines), encoding="utf-8")
print(f"\n==== QA: {passed}/{len(results)} passed ====")
for n, d in failed: print(f"FAIL: {n} {d}")
print("Report written to QA-REPORT.md")
